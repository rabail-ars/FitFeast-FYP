# FitFeast-FYP
Final Year Project repository for FitFeast app
FitFeast – Personalized Meal Planning App

This is the GitHub repository for the FitFeast Final Year Project. It contains:

- Project Documentation (SRS, SDS, Report)
- Test Plan & Test Cases
- Source Code (Flutter + Python + MySQL)
- Demo Video
- Poster

Team Members: Rabail Arshad, Sara Shehnaz, Maryam Shehnaz
